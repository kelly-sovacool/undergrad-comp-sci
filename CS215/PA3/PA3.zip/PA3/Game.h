
#ifndef Game_h
#define Game_h
#include <string>
#include <iostream>
using namespace std;
class Game {
public:
	Game(string n, int c, double p, double s) :name(n), count(c), price(p), score(s) {}
private:
	string name; //game name
	int count; //number of copies in stock
	double price; //game price
	double score; //user score, in the range [0, 10.0]
	friend class GameList;
};
#endif /* Game_h */
