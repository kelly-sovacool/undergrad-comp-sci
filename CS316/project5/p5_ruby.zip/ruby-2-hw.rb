#!/usr/bin/ruby
someVar = "Hello, World!"
puts "#{someVar}"
