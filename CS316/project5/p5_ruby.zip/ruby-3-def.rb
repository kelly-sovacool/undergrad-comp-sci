#!/usr/bin/ruby

def someFunction(printMe)
	puts "#{printMe}"
end

someFunction("Hello, World!")
